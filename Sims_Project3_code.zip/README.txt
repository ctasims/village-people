VILLAGE PEOPLE MEET LORD GA

Cianan Sims (ctasims)
Project 3 for CS 523


OVERVIEW
I built a village simulation from scratch.
Then I evolved a genetic algorithm to see how long a village could survive with a GA assigning villager professions.

Professions:
Villagers take on the roles of farmers, crafters and guards.
Farmers produce food. One farmer can feed two people. Each villager requires 30 food per month to stay in max health.
Crafters produce goods and build houses. One crafter can "maintain" four other villagers. 
Guards reduce the severity of invasions, and they eat more food than everyone else.

CLASSES (objects):

Villager
Atomic unit of the village. Each villager ages, eats, produces work output, marries, has family, has kids, dies.
If a villager doesn't get enough food each month his health drops. If it reaches 0 he dies.
A villager also needs a certain amount of goods each month. With these he can stay at max productivity.

Family
Mother, father, up to ten kids.
Families share a single profession: farmer, crafter or guard.
When children grow up they start a new family and get a new profession.
Widows do not remarry.
Each month every family calculates its work output based on health, availability of goods for tools.

Village
The village keeps track of all the villagers, families and who's doing what.
It contains the primary "run" function, which continuously loops and calls for family/villager updates on a yearly and monthly basis.

House
A simple class for a house object, which families require to be at max productivity.
If a family lacks a house they must live with their grandparents.
Crafters build houses at a cost of 100 village goods.

Lord_Ga
This is the GA class. The GA controls the distribution of professions.
The "genome" is a list of professions. When a villager reaches adulthood and starts a family, a profession is chosen for him from this list.
The GA uses selection, mutation and crossover to evolve a successful genome.
This file also has helper functions for writing results to .csv files and for displaying the evolution plot.