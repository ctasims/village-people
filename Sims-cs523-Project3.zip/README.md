village-people
==============
Project 3 for CS 523

Use GA to evolve a hardy populace in a foreign land, or watch them die trying!
